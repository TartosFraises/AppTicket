from mysql_connector import MySqlConnector

# Informations de connexion
DATABASE_URL = "localhost"
DATABASE_NAME = "test_db"
DATABASE_USER = "root"
DATABASE_PASSWORD = "password"

# Initialisation de MySqlConnector
connector = MySqlConnector(DATABASE_URL, DATABASE_NAME, DATABASE_USER, DATABASE_PASSWORD)

# Créer les tables dans la base
connector.create_tables()

# Ajouter un utilisateur
connector.addUser(user_name="titi", email="titi@example.com")

# Vérifier si un utilisateur existe
if connector.userExist("titi"):
    print("L'utilisateur titi existe.")
else:
    print("L'utilisateur titi n'existe pas.")

# Fermer la connexion
connector.close()
